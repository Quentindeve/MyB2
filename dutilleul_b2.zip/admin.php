<!DOCTYPE html>
<html>

<head>
    <title>Site Vitrine - Admin</title>
    <link rel="stylesheet" href="./static/style/tailwind.css">
    <link rel="stylesheet" href="./static/style/custom.css">
</head>

<body>
    <header class="flex flex-row bg-blue-600 items-center gap-5 p-2 sticky top-0">
        <img src="./static/img/logo.svg" class="w-1/5 h-1/5" />
        <a href="index.php">Accueil</a>
        <a href="products.php">Produits</a>
        <a href="admin.php">Admin</a>
        <?php
        session_start();
        extract($_SESSION);

        if (isset($admin) && $admin) {
            echo '<a href="add_product.php">Ajouter un produit</a>';
            echo '<a href="delete_product.php">Supprimer un produit</a>';
            echo '<a href="edit_product.php">Modifier un produit</a>';
        }
        ?>
    </header>

    <form action="admin.php" method="post">
        <label for="username">Nom d'utilisateur</label>
        <input type="text" name="username" />
        <label for="password">Mot de passe</label>
        <input type="password" name="password" />
        <input type="submit" name="submit" value="Se connecter">
    </form>

    <?php
    // Probablement le pire système de connexion que j'ai fait/vu de ma vie
    if (isset($_POST["submit"])) {
        extract($_POST);

        $USERNAME = "admin";
        $PASSWORD = "password";

        if ($username == $USERNAME && $password == $PASSWORD) {
            session_start();
            $_SESSION["admin"] = true;
            echo "<p class=\"text-green-600\"> Connecté !</p>";

            header("Location: index.php");
            die();
        } else {
            echo "<p class=\"text-red-600\">Erreur: nom d'utilisateur ou mot de passe invalide.</p>";
        }
    }
    ?>
</body>

</html>