<!DOCTYPE html>
<html>

<head>
    <title>Site Vitrine - Nos Produits</title>
    <link rel="stylesheet" href="./static/style/tailwind.css">
    <link rel="stylesheet" href="./static/style/custom.css">
</head>

<body class="bg-slate-100">
    <header class="flex flex-row bg-blue-600 items-center gap-5 p-2 sticky top-0 mb-10">
        <img src="./static/img/logo.svg" class="w-1/5 h-1/5" />
        <a href="index.php">Accueil</a>
        <a href="products.php">Produits</a>
        <a href="admin.php">Admin</a>
        <?php
        session_start();
        extract($_SESSION);

        if (isset($admin) && $admin) {
            echo '<a href="add_product.php">Ajouter un produit</a>';
            echo '<a href="delete_product.php">Supprimer un produit</a>';
            echo '<a href="edit_product.php">Modifier un produit</a>';
        }
        ?>
    </header>

    <?php
    include("config.php");

    $stmt = $db->prepare("SELECT * from products");
    $result = $stmt->execute();

    if (!$result) {
        echo "<p class='text-red-700'>Cette action n'a pas pu être effectuée: $error</p>";
    }

    $products = $stmt->fetchAll();

    echo "<div class='flex flex-row m-5'>";
    foreach ($products as $product) {
        $image = base64_encode($product["image"]);
        $image_mime = "image/jpeg";
        $img_code = '<img class="img-table-scale" src="data:' . $image_mime . ';base64,' . $image . '" />';

        $name = $product["name"];
        $price = $product["price"];
        $description = $product["description"];

        echo
        "<div class='bg-slate-300 flex flex-col max-h-fit max-w-fit p-3 ml-2 mr-2'>
            <span>$name</span>
            $img_code
            <span>$description</span>
            <span>$price €</span>
        </div>";
    }

    echo "</div>";

    ?>

</body>