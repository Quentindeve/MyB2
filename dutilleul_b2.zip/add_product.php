<!DOCTYPE html>
<html>

<head>
    <title>SiteVitrine - Ajout d'un produit</title>
    <link rel="stylesheet" href="./static/style/tailwind.css">
    <link rel="stylesheet" href="./static/style/custom.css">
</head>

<body>
    <header class="flex flex-row bg-blue-600 items-center gap-5 p-2 sticky top-0">
        <img src="./static/img/logo.svg" class="w-1/5 h-1/5" />
        <a href="index.php">Accueil</a>
        <a href="products.php">Produits</a>
        <a href="admin.php">Admin</a>
        <?php
        session_start();
        extract($_SESSION);

        if (isset($admin) && $admin) {
            echo '<a href="add_product.php">Ajouter un produit</a>';
            echo '<a href="delete_product.php">Supprimer un produit</a>';
            echo '<a href="edit_product.php">Modifier un produit</a>';
        }
        ?>
    </header>

    <form enctype="multipart/form-data" method="post" action="add_product.php" class="flex flex-col">
        <label for="product_name">Nom du produit</label>
        <input type="text" name="product_name" class="border-solid rounded-sm border-blue-600">

        <label for="product_price">Prix du produit</label>
        <input type="number" name="product_price">

        <label for="product_description">Description du produit</label>
        <input type="text" name="product_description">

        <label for="product_illustration">Illustration</label>
        <input type="file" name="product_illustration">

        <input type="submit" name="submitted">
    </form>

    <?php
    extract($_POST);
    if (isset($submitted)) {
        include("config.php");
        $file_content = file_get_contents($filename = $_FILES["product_illustration"]["tmp_name"]);
        $stmt = $db->prepare("INSERT INTO products(image, name, price, description) VALUES (:image, :name, :price, :description)");

        $stmt->bindParam(":image", $file_content);
        $stmt->bindParam(":name", $product_name);
        $stmt->bindParam(":price", $product_price);
        $stmt->bindParam(":description", $product_description);

        $stmt->execute();
    }
    ?>
</body>

</html>