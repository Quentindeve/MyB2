CREATE TABLE `products`
(
 `image`       varchar(32) NOT NULL ,
 `name`        varchar(200) NOT NULL ,
 `price`       float NOT NULL ,
 `description` varchar(500) NOT NULL ,

PRIMARY KEY (`image`)
);
